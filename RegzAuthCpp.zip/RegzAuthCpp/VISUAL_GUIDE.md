# 🎨 Visual Guide - RegzAuth C++ Dark Theme

## 📐 Exact Layout Specifications

### Window Dimensions
```
Width:  510 pixels
Height: 320 pixels
Position: Center screen
Resizable: No
Background: #151515 (RGB 21, 21, 21)
```

### Control Layout

```
┌─────────────────────────────────────────────────────────┐
│                                                         │ y=0
│                                                         │
│   ╔═══════════════════════════════════════════════╗   │ y=30
│   ║     Regz Auth Py Example                      ║   │ h=40
│   ╚═══════════════════════════════════════════════╝   │
│                                                         │
│   ┌───────────────────────────────────────────────┐   │ y=90
│   │ Username                                      │   │ h=29
│   └───────────────────────────────────────────────┘   │
│                                                         │
│   ┌───────────────────────────────────────────────┐   │ y=129
│   │ Password                                      │   │ h=29
│   └───────────────────────────────────────────────┘   │
│                                                         │
│   ┌───────────────────────────────────────────────┐   │ y=168
│   │ License Key                                   │   │ h=29
│   └───────────────────────────────────────────────┘   │
│                                                         │
│   ┌───────────────────────────────────────────────┐   │ y=207
│   │                    Login                      │   │ h=28
│   └───────────────────────────────────────────────┘   │
│   ┌───────────────────────────────────────────────┐   │ y=240
│   │                  Register                     │   │ h=28
│   └───────────────────────────────────────────────┘   │
│                                                         │
│                   Buy Account                          │ y=278
│                                                         │ h=20
└─────────────────────────────────────────────────────────┘ y=320
    x=0          x=95              x=415          x=510

Title: x=0, y=30, w=510, h=40 (center aligned)
Inputs: x=95, w=320 (centered)
Buttons: x=105, w=300 (centered)
Link: x=180, w=150 (centered)
```

## 🎨 Color Palette

### Primary Colors
```cpp
// Background
COLOR_BACKGROUND = RGB(21, 21, 21)     // #151515
┌────────────────┐
│    #151515     │ ← Very dark gray (almost black)
└────────────────┘

// Input Controls
COLOR_CONTROL_BG = RGB(44, 44, 44)     // #2c2c2c
┌────────────────┐
│    #2c2c2c     │ ← Dark gray
└────────────────┘

// Login Button
COLOR_LOGIN_BTN = RGB(0, 191, 255)     // #00BFFF
┌────────────────┐
│    #00BFFF     │ ← Cyan blue
└────────────────┘

// Register Button
COLOR_BUTTON_BG = RGB(33, 33, 33)      // #212121
┌────────────────┐
│    #212121     │ ← Dark gray
└────────────────┘
```

### Text Colors
```cpp
// White text (title, labels, register button)
COLOR_TEXT_WHITE = RGB(255, 255, 255)  // #FFFFFF
[████████] ← White

// Black text (login button)
COLOR_TEXT_BLACK = RGB(0, 0, 0)        // #000000
[        ] ← Black

// Cyan text (link)
COLOR_LOGIN_BTN = RGB(0, 191, 255)     // #00BFFF
[████████] ← Cyan
```

## 🔤 Typography

### Title Font
```
Font Family: Arial
Font Size: 28pt
Font Weight: Bold (FW_BOLD)
Color: White (#FFFFFF)
Alignment: Center
```

### Normal Font
```
Font Family: Arial
Font Size: 16pt
Font Weight: Normal (FW_NORMAL)
Color: White (#FFFFFF)
Alignment: Left
```

### Link Font
```
Font Family: Arial
Font Size: 14pt
Font Weight: Normal (FW_NORMAL)
Color: Cyan (#00BFFF)
Alignment: Center
Underlined: Yes
Cursor: Hand
```

## 🖼️ Visual Mockup

### Full Window (Actual Colors)
```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ ● Regz Auth Py Example                    ─ □ ✕ ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ┃ ← #151515
┃ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ┃
┃ ░░░╔════════════════════════════════════╗░░░░░░ ┃
┃ ░░░║   Regz Auth Py Example             ║░░░░░░ ┃ ← White, Bold, 28pt
┃ ░░░╚════════════════════════════════════╝░░░░░░ ┃
┃ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ┃
┃ ░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░ ┃
┃ ░░░▒ Username                           ▒░░░░░░░ ┃ ← #2c2c2c
┃ ░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░ ┃
┃ ░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░ ┃
┃ ░░░▒ Password                           ▒░░░░░░░ ┃ ← #2c2c2c
┃ ░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░ ┃
┃ ░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░ ┃
┃ ░░░▒ License Key                        ▒░░░░░░░ ┃ ← #2c2c2c
┃ ░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░ ┃
┃ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ┃
┃ ░░░╔════════════════════════════════════╗░░░░░░ ┃
┃ ░░░║            Login                   ║░░░░░░ ┃ ← #00BFFF (Cyan)
┃ ░░░╚════════════════════════════════════╝░░░░░░ ┃   Black text
┃ ░░░▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░ ┃
┃ ░░░▓          Register                 ▓░░░░░░░ ┃ ← #212121 (Dark gray)
┃ ░░░▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░ ┃   White text
┃ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ┃
┃ ░░░░░░░░░░░  Buy Account  ░░░░░░░░░░░░░░░░░░░░ ┃ ← Cyan, Underlined
┃ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

Legend:
░ = Background (#151515)
▒ = Input fields (#2c2c2c)
║ = Login button (#00BFFF)
▓ = Register button (#212121)
```

## 🎯 Control States

### Input Fields (Edit Controls)
```
Normal State:
┌────────────────────────┐
│ Username               │ ← #2c2c2c background
└────────────────────────┘   White text

Focused State:
┌────────────────────────┐
│ Username|              │ ← #2c2c2c background
└────────────────────────┘   White text + cursor

With Placeholder:
┌────────────────────────┐
│ Username               │ ← Gray placeholder text
└────────────────────────┘   (cue banner)
```

### Buttons

#### Login Button
```
Normal:
╔════════════════════════╗
║        Login           ║ ← #00BFFF background
╚════════════════════════╝   Black text

Hover:
╔════════════════════════╗
║        Login           ║ ← #00BFFF (slightly lighter)
╚════════════════════════╝   Black text

Pressed:
╔════════════════════════╗
║        Login           ║ ← #00BFFF (slightly darker)
╚════════════════════════╝   Black text
```

#### Register Button
```
Normal:
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
▓      Register        ▓ ← #212121 background
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓   White text

Hover:
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
▓      Register        ▓ ← #212121 (slightly lighter)
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓   White text
```

### Link
```
Normal:
  Buy Account          ← Cyan, Underlined
  ~~~~~~~~~~~

Hover:
  Buy Account          ← Cyan, Underlined, Hand cursor
  ~~~~~~~~~~~
```

## 📏 Spacing & Margins

```
Top margin (title): 30px
Title height: 40px
Gap after title: 20px

First input (username): y=90px
Input spacing: 39px (29px height + 10px gap)
Gap after last input: 10px

First button (login): y=207px
Button spacing: 33px (28px height + 5px gap)
Gap after last button: 10px

Link: y=278px
Link height: 20px
Bottom margin: 22px

Total: 30 + 40 + 20 + (29+10) + (29+10) + (29+10) + (28+5) + (28+10) + 20 + 22 = 310px
(Fits in 320px window)
```

## 🎨 Complete Color Reference

### Hex to RGB Conversion
```
#151515 = RGB(21, 21, 21)      = HSL(0°, 0%, 8%)   ← Background
#2c2c2c = RGB(44, 44, 44)      = HSL(0°, 0%, 17%)  ← Input fields
#00BFFF = RGB(0, 191, 255)     = HSL(195°, 100%, 50%) ← Login button & link
#212121 = RGB(33, 33, 33)      = HSL(0°, 0%, 13%)  ← Register button
#FFFFFF = RGB(255, 255, 255)   = HSL(0°, 0%, 100%) ← White text
#000000 = RGB(0, 0, 0)         = HSL(0°, 0%, 0%)   ← Black text
```

## 🖌️ Implementation Code

### Creating Colors
```cpp
// Define in LoginGUI.cpp
#define COLOR_BACKGROUND    RGB(21, 21, 21)      // #151515
#define COLOR_CONTROL_BG    RGB(44, 44, 44)      // #2c2c2c
#define COLOR_BUTTON_BG     RGB(33, 33, 33)      // #212121
#define COLOR_LOGIN_BTN     RGB(0, 191, 255)     // #00BFFF
#define COLOR_TEXT_WHITE    RGB(255, 255, 255)   // #FFFFFF
#define COLOR_TEXT_BLACK    RGB(0, 0, 0)         // #000000

// Create brushes
HBRUSH hBackgroundBrush = CreateSolidBrush(COLOR_BACKGROUND);
HBRUSH hControlBrush = CreateSolidBrush(COLOR_CONTROL_BG);
```

### Creating Fonts
```cpp
// Title font: Arial 28pt Bold
HFONT hTitleFont = CreateFontA(
    28,                      // Height
    0,                       // Width
    0,                       // Escapement
    0,                       // Orientation
    FW_BOLD,                 // Weight
    FALSE,                   // Italic
    FALSE,                   // Underline
    FALSE,                   // StrikeOut
    DEFAULT_CHARSET,
    OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS,
    CLEARTYPE_QUALITY,
    DEFAULT_PITCH | FF_DONTCARE,
    "Arial"
);

// Normal font: Arial 16pt
HFONT hNormalFont = CreateFontA(16, 0, 0, 0, FW_NORMAL, 
    FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, 
    DEFAULT_PITCH | FF_DONTCARE, "Arial");

// Link font: Arial 14pt Underlined
HFONT hLinkFont = CreateFontA(14, 0, 0, 0, FW_NORMAL, 
    FALSE, TRUE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
    CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, 
    DEFAULT_PITCH | FF_DONTCARE, "Arial");
```

### Creating Controls
```cpp
// Title
CreateWindowA("STATIC", "Regz Auth Py Example",
    WS_CHILD | WS_VISIBLE | SS_CENTER,
    0, 30, 510, 40, hwnd, NULL, NULL, NULL);

// Username input
CreateWindowExA(0, "EDIT", "",
    WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
    95, 90, 320, 29, hwnd, (HMENU)IDC_USERNAME, NULL, NULL);

// Login button (owner-draw for custom colors)
CreateWindowA("BUTTON", "Login",
    WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
    105, 207, 300, 28, hwnd, (HMENU)IDC_BTN_LOGIN, NULL, NULL);
```

## 🎬 Animation & Interaction

### Button Hover Effect (Optional Enhancement)
```cpp
// Track mouse to detect hover
TRACKMOUSEEVENT tme;
tme.cbSize = sizeof(TRACKMOUSEEVENT);
tme.dwFlags = TME_HOVER | TME_LEAVE;
tme.hwndTrack = hButton;
tme.dwHoverTime = HOVER_DEFAULT;
TrackMouseEvent(&tme);

// On WM_MOUSEHOVER: Draw lighter color
// On WM_MOUSELEAVE: Draw normal color
```

### Input Focus Indicator
```cpp
// Already built-in with WS_BORDER style
// Shows system focus rectangle when focused
```

## 📸 Screenshot Comparison

### Python (customtkinter)
```
✅ Dark background (#151515)
✅ Dark gray inputs (#2c2c2c)
✅ Cyan login button (#00BFFF)
✅ Dark gray register button (#212121)
✅ White text on dark background
✅ Cyan clickable link
```

### C++ (This Implementation)
```
✅ Dark background (#151515) ← Exact match
✅ Dark gray inputs (#2c2c2c) ← Exact match
✅ Cyan login button (#00BFFF) ← Exact match
✅ Dark gray register button (#212121) ← Exact match
✅ White text on dark background ← Exact match
✅ Cyan clickable link ← Exact match
```

**Result: 100% visual match! 🎉**

## 🎯 Checklist for Visual Accuracy

- [ ] Background is very dark gray (#151515)
- [ ] Input fields are dark gray (#2c2c2c)
- [ ] Login button is cyan (#00BFFF) with black text
- [ ] Register button is dark gray (#212121) with white text
- [ ] Title is white, bold, 28pt Arial
- [ ] Title says "Regz Auth Py Example"
- [ ] "Buy Account" link is cyan and underlined
- [ ] Window is 510×320 pixels
- [ ] No CMD window appears
- [ ] Inputs have placeholder text
- [ ] All spacing matches mockup

If all checked, you have perfect visual accuracy! ✨

---

**This is the exact design implemented in `src/LoginGUI.cpp`!**


# ✅ Test Steps - Verify Everything Works

Follow these steps to test your new dark theme GUI!

## 🎯 Test 1: Database Setup

### Step 1.1: Run SQL Setup
1. Open Supabase Dashboard
2. Go to SQL Editor
3. Copy entire contents of `DATABASE_SETUP.sql`
4. Click "Run"

**Expected Result:**
```
✅ 3 rows inserted into license_keys
✅ Query completed successfully
```

### Step 1.2: Verify License Keys
Run this query:
```sql
SELECT license_key, admin_approval, banned, duration_days 
FROM public.license_keys;
```

**Expected Result:**
```
TEST-KEY-2024-DEMO    | true  | false | 365
PREMIUM-2024-TEST     | true  | false | 365
VIP-2024-GOLD         | true  | false | 730
```

**❌ If you see `admin_approval = false`:**
```sql
UPDATE license_keys SET admin_approval = true;
```

---

## 🎯 Test 2: Build Project

### Step 2.1: Open in Visual Studio
```bash
cd RegzAuthCpp
start RegzAuthCpp.sln
```

### Step 2.2: Check Configuration
1. Right-click `RegzAuthCpp` project → Properties
2. Configuration Properties → Linker → System
3. Verify: `SubSystem = Windows (/SUBSYSTEM:WINDOWS)`

**Expected:** SubSystem shows "Windows", NOT "Console"

### Step 2.3: Build
1. Press `Ctrl+Shift+B` or click Build → Build Solution
2. Wait for build to complete

**Expected Result:**
```
Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped
```

**❌ If build fails**, check:
- All files exist in correct folders
- `LoginGUI.h`, `LoginGUI.cpp`, `LoginGUI.rc` are in `src/`
- Project file includes all new files

---

## 🎯 Test 3: Launch GUI

### Step 3.1: Run Application
Press `F5` or click "Start Debugging"

**Expected Result:**
- ✅ GUI window appears immediately
- ✅ NO console/CMD window appears
- ✅ Window title: "Regz Auth Py Example"
- ✅ Dark background (#151515)
- ✅ "Regz Auth Py Example" title in white, large font

**❌ If CMD window appears:**
- Check SubSystem = Windows (see Step 2.2)
- Rebuild project

### Step 3.2: Verify GUI Elements

**Expected UI Elements:**
1. ✅ Title: "Regz Auth Py Example" (white, bold)
2. ✅ Username input (dark gray #2c2c2c)
3. ✅ Password input (dark gray #2c2c2c, shows ****)
4. ✅ License Key input (dark gray #2c2c2c)
5. ✅ Login button (cyan #00BFFF, black text)
6. ✅ Register button (dark gray #212121, white text)
7. ✅ "Buy Account" link (cyan #00BFFF, underlined)

**Visual Check:**
```
┌──────────────────────────────────┐
│   Regz Auth Py Example           │ ← White, bold, 28pt
│                                  │
│   [Username         ]            │ ← Dark gray box
│   [Password         ]            │ ← Dark gray box
│   [License Key      ]            │ ← Dark gray box
│                                  │
│   [      Login      ]            │ ← Cyan button
│   [    Register     ]            │ ← Dark gray button
│                                  │
│      Buy Account                 │ ← Cyan underlined link
│                                  │
└──────────────────────────────────┘
Background: Very dark gray (#151515)
```

---

## 🎯 Test 4: Registration

### Step 4.1: Fill Registration Form
1. **Username**: `testuser1`
2. **Password**: `test123`
3. **License Key**: `TEST-KEY-2024-DEMO`
4. Click **"Register"** button

**Expected Result:**
```
✅ Message box appears: "Registration successful! You can now log in."
✅ Username and password are saved
✅ Dialog stays open
```

**❌ If "Registration failed":**

**Check 1: License Key in Database**
```sql
SELECT * FROM license_keys WHERE license_key = 'TEST-KEY-2024-DEMO';
```
- Must exist
- `admin_approval` must be `true`
- `banned` must be `false`
- `duration_days` must be > 0

**Check 2: Verify User Created**
```sql
SELECT username, admin_approval, banned FROM users WHERE username = 'testuser1';
```
- Should show new user
- `admin_approval` should be `true`
- `banned` should be `false`

**Check 3: License Key Consumed**
```sql
-- License key should be DELETED after successful registration
SELECT * FROM license_keys WHERE license_key = 'TEST-KEY-2024-DEMO';
-- Should return 0 rows
```

### Step 4.2: Try Duplicate Registration
1. Try to register `testuser1` again with a different license key
2. Click "Register"

**Expected Result:**
```
❌ "Registration failed: ..."
(User already exists)
```

---

## 🎯 Test 5: Login

### Step 5.1: Fill Login Form
1. **Username**: `testuser1`
2. **Password**: `test123`
3. Click **"Login"** button

**Expected Result:**
```
✅ Welcome message appears: "Welcome! Subscriptions: Supreme-Essential-External-Experiment"
✅ Dialog closes
✅ Credentials saved to %APPDATA%\RegzAuthCppExample.json
```

### Step 5.2: Verify Credentials Saved
1. Press `Win+R`
2. Type: `%APPDATA%`
3. Look for: `RegzAuthCppExample.json`
4. Open it

**Expected Content:**
```json
{"username":"testuser1","password":"test123"}
```

### Step 5.3: Test Credential Auto-Load
1. Run the application again
2. Observe username and password fields

**Expected Result:**
```
✅ Username field pre-filled with "testuser1"
✅ Password field pre-filled with "test123"
✅ Just click "Login" to login instantly
```

### Step 5.4: Test Wrong Password
1. Change password to something wrong
2. Click "Login"

**Expected Result:**
```
❌ Message: "Login failed: Invalid credentials or account not approved"
```

---

## 🎯 Test 6: Buy Account Link

### Step 6.1: Click Link
1. Click "Buy Account" link at bottom of dialog

**Expected Result:**
```
✅ Browser opens
✅ Navigates to: https://regzcheat.org/
```

---

## 🎯 Test 7: Database Logging

### Step 7.1: Check Login Logs
```sql
SELECT * FROM login_details 
WHERE username = 'testuser1' 
ORDER BY login_time DESC 
LIMIT 5;
```

**Expected Result:**
```
✅ Shows login entries with:
  - username: testuser1
  - ip_address: (your IP)
  - hwid: (your hardware ID)
  - pc_name: (your computer name)
  - os_version, cpu_serial, etc.
```

### Step 7.2: Check Application Open Logs
```sql
SELECT * FROM application_open 
ORDER BY timestamp DESC 
LIMIT 5;
```

**Expected Result:**
```
✅ Shows app open entries with system info
```

---

## 🎯 Test 8: Error Cases

### Test 8.1: Empty Fields
1. Leave username empty
2. Click "Login"

**Expected:** `"Please enter username and password."`

### Test 8.2: Empty License Key
1. Fill username and password
2. Leave license key empty
3. Click "Register"

**Expected:** `"Please fill in all fields."`

### Test 8.3: Invalid License Key
1. Use license key: `INVALID-KEY-123`
2. Click "Register"

**Expected:** `"Registration failed: Invalid license key..."`

### Test 8.4: Banned User
```sql
-- Ban the test user
UPDATE users SET banned = true WHERE username = 'testuser1';
```

Try to login:

**Expected:** `"Login failed: ..."`

### Test 8.5: Expired Subscription
```sql
-- Expire the subscription
UPDATE users SET expiredate = '2020-01-01' WHERE username = 'testuser1';
```

Try to login:

**Expected:** `"Login failed: ..."`

---

## 🎯 Test 9: HWID Protection

### Test 9.1: View User HWID
```sql
SELECT username, hwid, max_devices FROM users WHERE username = 'testuser1';
```

**Expected Result:**
```
✅ hwid: ["SHA256_HASH_HERE"]
✅ max_devices: 3
```

### Test 9.2: Simulate Different Computer
This is hard to test without another PC, but the system:
- Generates SHA-256 hash of motherboard serial
- Stores in array: `["hwid1", "hwid2", ...]`
- Rejects login if array length >= max_devices

---

## 🎯 Test 10: Clean Up

### Step 10.1: Delete Test User
```sql
DELETE FROM users WHERE username = 'testuser1';
```

### Step 10.2: Restore License Keys
```sql
-- Re-insert if you want to test again
INSERT INTO license_keys (license_key, admin_approval, banned, max_devices, duration_days, subscription)
VALUES ('TEST-KEY-2024-DEMO', true, false, 3, 365, '["default"]'::jsonb);
```

---

## ✅ Final Checklist

Mark each item as you test:

- [ ] Database setup completed
- [ ] License keys created with `admin_approval = true`
- [ ] Project builds successfully (no errors)
- [ ] GUI launches without CMD window
- [ ] Dark theme colors are correct (#151515, #2c2c2c, #00BFFF)
- [ ] Registration works with valid license key
- [ ] Login works with correct credentials
- [ ] Credentials auto-save and auto-load
- [ ] "Buy Account" link opens browser
- [ ] Error messages appear for invalid inputs
- [ ] Database logs login and app open events
- [ ] HWID is tracked and stored

---

## 🎉 Success Criteria

**All tests passed?** Congratulations! Your RegzAuth C++ GUI is working perfectly! 🚀

**Some tests failed?** Check:
1. `DATABASE_SETUP.sql` was run completely
2. Supabase URL and Key are correct in `gui_example.cpp`
3. All files are in correct folders (`src/` and `regzauth/`)
4. Project file includes all new files
5. SubSystem is set to "Windows" (not "Console")

Need help? Review:
- `README.md` - Full documentation
- `QUICK_START.md` - Quick setup guide
- `COMPARISON.md` - Visual comparison
- `CHANGES.md` - What changed

**Happy coding! 🎊**


#pragma once

#ifndef REGZAUTH_SYSTEMINFO_H
#define REGZAUTH_SYSTEMINFO_H

#include "RegzAuthInternal.h"

namespace RegzAuth {

class SystemInfoCollector {
public:
    SystemInfoCollector();
    ~SystemInfoCollector();

    SystemInfo GetSystemInfo();
    std::string GetHWID();
    std::string GetMotherboardSerial();
    std::string GetCPUSerial();
    std::string GetOSVersion();
    std::string GetRAMCapacity();
    std::string GetGraphicsCard();
    std::string GetStorageCapacity();
    std::string GetPCName();
    std::string GetIPAddress();

private:
    std::string executeCommand(const std::string& command);
    std::string sha256Hash(const std::string& input);
};

} // namespace RegzAuth

#endif // REGZAUTH_SYSTEMINFO_H

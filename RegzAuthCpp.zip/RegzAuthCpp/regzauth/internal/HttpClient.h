#pragma once

#ifndef REGZAUTH_HTTPCLIENT_H
#define REGZAUTH_HTTPCLIENT_H

#include "RegzAuthInternal.h"
#include <wininet.h>

#pragma comment(lib, "wininet.lib")

namespace RegzAuth {

class HttpClient {
public:
    HttpClient();
    ~HttpClient();

    std::string Post(const std::string& url, const std::string& data, const std::string& headers = "");
    std::string Get(const std::string& url, const std::string& headers = "");
    bool IsConnected();

private:
    HINTERNET hInternet;
    HINTERNET hConnect;
    
    std::string urlEncode(const std::string& str);
    std::string getResponseBody(HINTERNET hRequest);
};

} // namespace RegzAuth

#endif // REGZAUTH_HTTPCLIENT_H

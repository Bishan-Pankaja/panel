#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include "AuthManager.h"
#include "HttpClient.h"
#include "SystemInfo.h"
#include <iostream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <map>

namespace RegzAuth {

AuthManager::AuthManager() : appVersion("1.0") {
    httpClient = std::make_unique<HttpClient>();
    systemInfo = std::make_unique<SystemInfoCollector>();
}

AuthManager::~AuthManager() {
}

void AuthManager::SetSupabaseConfig(const std::string& url, const std::string& key) {
    supabaseUrl = url;
    supabaseKey = key;
}

void AuthManager::SetAppVersion(const std::string& version) {
    appVersion = version;
}

bool AuthManager::ConnectToDatabase() {
    return httpClient->IsConnected();
}

bool AuthManager::RegisterUser(const std::string& username, const std::string& password, const std::string& licenseKey) {
    if (!ConnectToDatabase()) {
        return false;
    }

    try {
        // Check if username already exists
        std::string checkUrl = supabaseUrl + "/rest/v1/users?username=eq." + username + "&select=id";
        std::string headers = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey;
        std::string response = httpClient->Get(checkUrl, headers);
        
        if (response.find("[{") != std::string::npos && response.find("id") != std::string::npos) {
            return false; // Username already exists
        }

        // Validate license key
        std::string keyUrl = supabaseUrl + "/rest/v1/license_keys?license_key=eq." + licenseKey + "&select=*";
        std::string keyResponse = httpClient->Get(keyUrl, headers);
        
        if (keyResponse.find("[{") == std::string::npos) {
            return false; // Invalid license key
        }

        // Parse license key data
        std::string subscription = ParseJsonValue(keyResponse, "subscription");
        std::string expiredate = ParseJsonValue(keyResponse, "expiredate");
        bool adminApproval = ParseJsonBool(keyResponse, "admin_approval");
        int maxDevices = ParseJsonInt(keyResponse, "max_devices");
        bool banned = ParseJsonBool(keyResponse, "banned");

        if (banned) return false;
        if (!adminApproval) return false;

        // Check expiration date
        if (!expiredate.empty()) {
            std::tm tm = {};
            std::istringstream ss(expiredate);
            ss >> std::get_time(&tm, "%Y-%m-%d");
            std::time_t expireTime = std::mktime(&tm);
            std::time_t currentTime = std::time(nullptr);
            
            if (expireTime < currentTime) {
                return false; // Expired
            }
        }

        // Register the user
        std::string hwid = systemInfo->GetHWID();
        std::map<std::string, std::string> userData;
        userData["username"] = username;
        userData["password"] = password;
        userData["key"] = licenseKey;
        userData["hwid"] = "[\"" + hwid + "\"]";
        userData["subscription"] = subscription;
        userData["expiredate"] = expiredate;
        userData["admin_approval"] = adminApproval ? "true" : "false";
        userData["max_devices"] = std::to_string(maxDevices);

        std::string jsonData = BuildJsonData(userData);
        std::string insertUrl = supabaseUrl + "/rest/v1/users";
        std::string insertHeaders = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey + "\r\nContent-Type: application/json";
        std::string insertResponse = httpClient->Post(insertUrl, jsonData, insertHeaders);

        // Remove the license key
        std::string deleteUrl = supabaseUrl + "/rest/v1/license_keys?license_key=eq." + licenseKey;
        std::string deleteHeaders = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey;
        httpClient->Post(deleteUrl, "", deleteHeaders);

        return insertResponse.find("error") == std::string::npos;
    }
    catch (const std::exception& e) {
        std::cerr << "Registration error: " << e.what() << std::endl;
        return false;
    }
}

bool AuthManager::CheckLogin(const std::string& username, const std::string& password) {
    if (!CheckVersion()) {
        return false;
    }

    std::string hwid = systemInfo->GetHWID();
    if (!ConnectToDatabase()) {
        return false;
    }

    try {
        // Check user credentials
        std::string loginUrl = supabaseUrl + "/rest/v1/users?username=eq." + username + "&password=eq." + password + "&select=*";
        std::string headers = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey;
        std::string response = httpClient->Get(loginUrl, headers);

        if (response.find("[{") == std::string::npos) {
            LogLogin(username, "failed");
            return false;
        }

        // Parse user data
        UserData user;
        user.id = ParseJsonValue(response, "id");
        user.username = ParseJsonValue(response, "username");
        user.password = ParseJsonValue(response, "password");
        user.key = ParseJsonValue(response, "key");
        user.hwid = ParseJsonArray(response, "hwid");
        user.subscription = ParseJsonValue(response, "subscription");
        user.expiredate = ParseJsonValue(response, "expiredate");
        user.adminApproval = ParseJsonBool(response, "admin_approval");
        user.maxDevices = ParseJsonInt(response, "max_devices");
        user.banned = ParseJsonBool(response, "banned");
        user.saveHwid = ParseJsonBool(response, "save_hwid");

        if (user.banned) {
            LogLogin(username, "failed");
            return false;
        }

        if (!user.adminApproval) {
            LogLogin(username, "failed");
            return false;
        }

        // Check subscription expiry
        if (!user.expiredate.empty()) {
            std::tm tm = {};
            std::istringstream ss(user.expiredate);
            ss >> std::get_time(&tm, "%Y-%m-%d");
            std::time_t expireTime = std::mktime(&tm);
            std::time_t currentTime = std::time(nullptr);
            
            if (expireTime < currentTime) {
                LogLogin(username, "failed");
                return false;
            }
        }

        // HWID verification
        if (user.saveHwid) {
            bool hwidFound = false;
            for (const auto& h : user.hwid) {
                if (h == hwid) {
                    hwidFound = true;
                    break;
                }
            }

            if (!hwidFound) {
                if (user.hwid.size() < user.maxDevices) {
                    // Add new HWID
                    user.hwid.push_back(hwid);
                    std::string hwidJson = "[";
                    for (size_t i = 0; i < user.hwid.size(); ++i) {
                        if (i > 0) hwidJson += ",";
                        hwidJson += "\"" + user.hwid[i] + "\"";
                    }
                    hwidJson += "]";

                    std::map<std::string, std::string> updateData;
                    updateData["hwid"] = hwidJson;
                    std::string updateJson = BuildJsonData(updateData);
                    std::string updateUrl = supabaseUrl + "/rest/v1/users?id=eq." + user.id;
                    std::string updateHeaders = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey + "\r\nContent-Type: application/json";
                    httpClient->Post(updateUrl, updateJson, updateHeaders);
                } else {
                    LogLogin(username, "failed");
                    return false;
                }
            }
        }

        HandleSuccessfulLogin(username, password, user);
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "Login error: " << e.what() << std::endl;
        LogLogin(username, "failed");
        return false;
    }
}

bool AuthManager::CheckVersion() {
    try {
        if (!ConnectToDatabase()) {
            return false;
        }

        std::string versionUrl = supabaseUrl + "/rest/v1/app_version?select=version&order=id.desc&limit=1";
        std::string headers = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey;
        std::string response = httpClient->Get(versionUrl, headers);

        if (response.find("[{") != std::string::npos) {
            std::string serverVersion = ParseJsonValue(response, "version");
            return appVersion == serverVersion;
        }
        return false;
    }
    catch (const std::exception& e) {
        std::cerr << "Version check error: " << e.what() << std::endl;
        return false;
    }
}

void AuthManager::LogLogin(const std::string& username, const std::string& status) {
    try {
        std::map<std::string, std::string> logData;
        logData["username"] = username;
        logData["status"] = status;
        
        auto now = std::time(nullptr);
        auto tm = *std::localtime(&now);
        std::ostringstream oss;
        oss << std::put_time(&tm, "%Y-%m-%dT%H:%M:%S");
        logData["timestamp"] = oss.str();

        std::string jsonData = BuildJsonData(logData);
        std::string logUrl = supabaseUrl + "/rest/v1/login_logs";
        std::string headers = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey + "\r\nContent-Type: application/json";
        httpClient->Post(logUrl, jsonData, headers);
    }
    catch (const std::exception& e) {
        std::cerr << "Log login error: " << e.what() << std::endl;
    }
}

void AuthManager::SaveLoginDetails(const std::string& username) {
    try {
        SystemInfo info = systemInfo->GetSystemInfo();
        
        std::map<std::string, std::string> details;
        details["username"] = username;
        details["pc_name"] = info.pcName;
        details["ip_address"] = info.ipAddress;
        details["hwid"] = info.hwid;
        details["motherboard_serial"] = info.motherboardSerial;
        details["cpu_serial"] = info.cpuSerial;
        details["os_version"] = info.osVersion;
        details["ram_capacity"] = info.ramCapacity;
        details["graphics_card"] = info.graphicsCard;
        details["storage_capacity"] = info.storageCapacity;

        std::string jsonData = BuildJsonData(details);
        std::string detailsUrl = supabaseUrl + "/rest/v1/login_details";
        std::string headers = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey + "\r\nContent-Type: application/json";
        httpClient->Post(detailsUrl, jsonData, headers);
    }
    catch (const std::exception& e) {
        std::cerr << "Save login details error: " << e.what() << std::endl;
    }
}

void AuthManager::LogApplicationOpen(const std::string& username) {
    try {
        SystemInfo info = systemInfo->GetSystemInfo();
        
        std::map<std::string, std::string> appData;
        appData["username"] = username;
        appData["pc_name"] = info.pcName;
        appData["ip_address"] = info.ipAddress;
        appData["hwid"] = info.hwid;
        appData["motherboard_serial"] = info.motherboardSerial;
        appData["cpu_serial"] = info.cpuSerial;
        appData["os_version"] = info.osVersion;
        appData["ram_capacity"] = info.ramCapacity;
        appData["graphics_card"] = info.graphicsCard;
        appData["storage_capacity"] = info.storageCapacity;

        auto now = std::time(nullptr);
        auto tm = *std::localtime(&now);
        std::ostringstream oss;
        oss << std::put_time(&tm, "%Y-%m-%dT%H:%M:%S");
        appData["timestamp"] = oss.str();

        std::string jsonData = BuildJsonData(appData);
        std::string appUrl = supabaseUrl + "/rest/v1/application_open";
        std::string headers = "apikey: " + supabaseKey + "\r\nAuthorization: Bearer " + supabaseKey + "\r\nContent-Type: application/json";
        httpClient->Post(appUrl, jsonData, headers);
    }
    catch (const std::exception& e) {
        std::cerr << "Log application open error: " << e.what() << std::endl;
    }
}

void AuthManager::HandleSuccessfulLogin(const std::string& username, const std::string& password, const UserData& user) {
    LogLogin(username, "success");
    SaveLoginDetails(username);
}

std::string AuthManager::BuildJsonData(const std::map<std::string, std::string>& data) {
    std::ostringstream json;
    json << "{";
    bool first = true;
    for (const auto& pair : data) {
        if (!first) json << ",";
        json << "\"" << pair.first << "\":\"" << pair.second << "\"";
        first = false;
    }
    json << "}";
    return json.str();
}

std::string AuthManager::ParseJsonValue(const std::string& json, const std::string& key) {
    std::string searchKey = "\"" + key + "\":\"";
    size_t start = json.find(searchKey);
    if (start == std::string::npos) return "";
    
    start += searchKey.length();
    size_t end = json.find("\"", start);
    if (end == std::string::npos) return "";
    
    return json.substr(start, end - start);
}

bool AuthManager::ParseJsonBool(const std::string& json, const std::string& key) {
    std::string searchKey = "\"" + key + "\":";
    size_t start = json.find(searchKey);
    if (start == std::string::npos) return false;
    
    start += searchKey.length();
    size_t end = json.find_first_of(",}", start);
    if (end == std::string::npos) return false;
    
    std::string value = json.substr(start, end - start);
    return value == "true";
}

int AuthManager::ParseJsonInt(const std::string& json, const std::string& key) {
    std::string searchKey = "\"" + key + "\":";
    size_t start = json.find(searchKey);
    if (start == std::string::npos) return 0;
    
    start += searchKey.length();
    size_t end = json.find_first_of(",}", start);
    if (end == std::string::npos) return 0;
    
    std::string value = json.substr(start, end - start);
    return std::stoi(value);
}

std::vector<std::string> AuthManager::ParseJsonArray(const std::string& json, const std::string& key) {
    std::vector<std::string> result;
    std::string searchKey = "\"" + key + "\":[";
    size_t start = json.find(searchKey);
    if (start == std::string::npos) return result;
    
    start += searchKey.length();
    size_t end = json.find("]", start);
    if (end == std::string::npos) return result;
    
    std::string arrayContent = json.substr(start, end - start);
    size_t pos = 0;
    while ((pos = arrayContent.find("\"", pos)) != std::string::npos) {
        size_t valueStart = pos + 1;
        size_t valueEnd = arrayContent.find("\"", valueStart);
        if (valueEnd != std::string::npos) {
            result.push_back(arrayContent.substr(valueStart, valueEnd - valueStart));
            pos = valueEnd + 1;
        } else {
            break;
        }
    }
    
    return result;
}

} // namespace RegzAuth

#pragma once

#ifndef REGZAUTH_AUTHMANAGER_H
#define REGZAUTH_AUTHMANAGER_H

#include "RegzAuthInternal.h"
#include "HttpClient.h"
#include "SystemInfo.h"

namespace RegzAuth {

class AuthManager {
public:
    AuthManager();
    ~AuthManager();

    bool RegisterUser(const std::string& username, const std::string& password, const std::string& licenseKey);
    bool CheckLogin(const std::string& username, const std::string& password);
    bool CheckVersion();
    void LogLogin(const std::string& username, const std::string& status);
    void SaveLoginDetails(const std::string& username);
    void LogApplicationOpen(const std::string& username);

    void SetSupabaseConfig(const std::string& url, const std::string& key);
    void SetAppVersion(const std::string& version);

private:
    std::string supabaseUrl;
    std::string supabaseKey;
    std::string appVersion;
    
    std::unique_ptr<HttpClient> httpClient;
    std::unique_ptr<SystemInfoCollector> systemInfo;

    bool ConnectToDatabase();
    void HandleSuccessfulLogin(const std::string& username, const std::string& password, const UserData& user);
    std::string BuildJsonData(const std::map<std::string, std::string>& data);
    std::string ParseJsonValue(const std::string& json, const std::string& key);
    bool ParseJsonBool(const std::string& json, const std::string& key);
    int ParseJsonInt(const std::string& json, const std::string& key);
    std::vector<std::string> ParseJsonArray(const std::string& json, const std::string& key);
};

} // namespace RegzAuth

#endif // REGZAUTH_AUTHMANAGER_H

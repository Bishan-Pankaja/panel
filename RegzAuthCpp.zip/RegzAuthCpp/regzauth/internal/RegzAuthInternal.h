#pragma once

// Internal headers for RegzAuth system
// These are used internally and don't need to be included by users

#ifndef REGZAUTH_INTERNAL_H
#define REGZAUTH_INTERNAL_H

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <string>
#include <vector>
#include <memory>
#include <map>
#include <functional>

namespace RegzAuth {

// Forward declarations
class HttpClient;
class SystemInfoCollector;
class AuthManager;

// System information structure
struct SystemInfo {
    std::string pcName;
    std::string ipAddress;
    std::string hwid;
    std::string motherboardSerial;
    std::string cpuSerial;
    std::string osVersion;
    std::string ramCapacity;
    std::string graphicsCard;
    std::string storageCapacity;
};

// User data structure
struct UserData {
    std::string id;
    std::string username;
    std::string password;
    std::string key;
    std::vector<std::string> hwid;
    std::string subscription;
    std::string expiredate;
    bool adminApproval;
    int maxDevices;
    bool banned;
    bool saveHwid;
};

// License key structure
struct LicenseKey {
    std::string licenseKey;
    std::string subscription;
    std::string expiredate;
    bool adminApproval;
    int maxDevices;
    bool banned;
};

} // namespace RegzAuth

#endif // REGZAUTH_INTERNAL_H

#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include "HttpClient.h"
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cctype>

namespace RegzAuth {

HttpClient::HttpClient() {
    hInternet = InternetOpenA("RegzAuth/1.0", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    hConnect = NULL;
}

HttpClient::~HttpClient() {
    if (hConnect) {
        InternetCloseHandle(hConnect);
    }
    if (hInternet) {
        InternetCloseHandle(hInternet);
    }
}

std::string HttpClient::Post(const std::string& url, const std::string& data, const std::string& headers) {
    if (!hInternet) return "";

    URL_COMPONENTSA urlComp;
    ZeroMemory(&urlComp, sizeof(urlComp));
    urlComp.dwStructSize = sizeof(urlComp);
    urlComp.dwSchemeLength = -1;
    urlComp.dwHostNameLength = -1;
    urlComp.dwUrlPathLength = -1;

    char hostName[256] = {0};
    char urlPath[1024] = {0};
    urlComp.lpszHostName = hostName;
    urlComp.lpszUrlPath = urlPath;

    if (!InternetCrackUrlA(url.c_str(), 0, 0, &urlComp)) {
        return "";
    }

    hConnect = InternetConnectA(hInternet, hostName, urlComp.nPort, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConnect) return "";

    DWORD flags = INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE | INTERNET_FLAG_SECURE;
    HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", urlPath, "HTTP/1.1", NULL, NULL, flags, 0);
    if (!hRequest) return "";

    std::string contentType = "Content-Type: application/json\r\n";
    if (!headers.empty()) {
        contentType += headers + "\r\n";
    }

    if (!HttpSendRequestA(hRequest, contentType.c_str(), -1, (LPVOID)data.c_str(), data.length())) {
        InternetCloseHandle(hRequest);
        return "";
    }

    std::string response = getResponseBody(hRequest);
    InternetCloseHandle(hRequest);
    return response;
}

std::string HttpClient::Get(const std::string& url, const std::string& headers) {
    if (!hInternet) return "";

    URL_COMPONENTSA urlComp;
    ZeroMemory(&urlComp, sizeof(urlComp));
    urlComp.dwStructSize = sizeof(urlComp);
    urlComp.dwSchemeLength = -1;
    urlComp.dwHostNameLength = -1;
    urlComp.dwUrlPathLength = -1;

    char hostName[256] = {0};
    char urlPath[1024] = {0};
    urlComp.lpszHostName = hostName;
    urlComp.lpszUrlPath = urlPath;

    if (!InternetCrackUrlA(url.c_str(), 0, 0, &urlComp)) {
        return "";
    }

    hConnect = InternetConnectA(hInternet, hostName, urlComp.nPort, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConnect) return "";

    DWORD flags = INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE | INTERNET_FLAG_SECURE;
    HINTERNET hRequest = HttpOpenRequestA(hConnect, "GET", urlPath, "HTTP/1.1", NULL, NULL, flags, 0);
    if (!hRequest) return "";

    if (!HttpSendRequestA(hRequest, headers.c_str(), -1, NULL, 0)) {
        InternetCloseHandle(hRequest);
        return "";
    }

    std::string response = getResponseBody(hRequest);
    InternetCloseHandle(hRequest);
    return response;
}

bool HttpClient::IsConnected() {
    return hInternet != NULL;
}

std::string HttpClient::getResponseBody(HINTERNET hRequest) {
    std::string response;
    char buffer[4096];
    DWORD bytesRead;

    while (InternetReadFile(hRequest, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
        response.append(buffer, bytesRead);
    }

    return response;
}

std::string HttpClient::urlEncode(const std::string& str) {
    std::ostringstream escaped;
    escaped.fill('0');
    escaped << std::hex;

    for (char c : str) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            escaped << c;
        } else {
            escaped << std::uppercase;
            escaped << '%' << std::setw(2) << int((unsigned char)c);
            escaped << std::nouppercase;
        }
    }

    return escaped.str();
}

} // namespace RegzAuth

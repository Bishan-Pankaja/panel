#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include "SystemInfo.h"
#include <psapi.h>
#include <iphlpapi.h>
#include <ws2tcpip.h>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <wincrypt.h>
#include <cstring>
#include <versionhelpers.h>

#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "crypt32.lib")

namespace RegzAuth {

SystemInfoCollector::SystemInfoCollector() {
    WSADATA wsaData;
    int result = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (result != 0) {
        // WSAStartup failed, but we'll continue anyway
        // In a production app, you might want to handle this error
    }
}

SystemInfoCollector::~SystemInfoCollector() {
    WSACleanup();
}

SystemInfo SystemInfoCollector::GetSystemInfo() {
    SystemInfo info;
    info.pcName = GetPCName();
    info.ipAddress = GetIPAddress();
    info.hwid = GetHWID();
    info.motherboardSerial = GetMotherboardSerial();
    info.cpuSerial = GetCPUSerial();
    info.osVersion = GetOSVersion();
    info.ramCapacity = GetRAMCapacity();
    info.graphicsCard = GetGraphicsCard();
    info.storageCapacity = GetStorageCapacity();
    return info;
}

std::string SystemInfoCollector::GetHWID() {
    std::string motherboardSerial = GetMotherboardSerial();
    return sha256Hash(motherboardSerial);
}

std::string SystemInfoCollector::GetMotherboardSerial() {
    return executeCommand("wmic baseboard get SerialNumber");
}

std::string SystemInfoCollector::GetCPUSerial() {
    return executeCommand("wmic cpu get ProcessorId");
}

std::string SystemInfoCollector::GetOSVersion() {
    // Use modern Windows version detection
    if (IsWindows10OrGreater()) {
        return "Windows 10 or later";
    } else if (IsWindows8Point1OrGreater()) {
        return "Windows 8.1 or later";
    } else if (IsWindows8OrGreater()) {
        return "Windows 8 or later";
    } else if (IsWindows7OrGreater()) {
        return "Windows 7 or later";
    } else if (IsWindowsVistaOrGreater()) {
        return "Windows Vista or later";
    } else if (IsWindowsXPOrGreater()) {
        return "Windows XP or later";
    } else {
        return "Windows (unknown version)";
    }
}

std::string SystemInfoCollector::GetRAMCapacity() {
    MEMORYSTATUSEX memStatus;
    memStatus.dwLength = sizeof(memStatus);
    if (GlobalMemoryStatusEx(&memStatus)) {
        std::ostringstream oss;
        oss << (memStatus.ullTotalPhys / (1024 * 1024 * 1024)) << " GB";
        return oss.str();
    }
    return "Unknown";
}

std::string SystemInfoCollector::GetGraphicsCard() {
    std::string result = executeCommand("wmic path win32_videocontroller get caption");
    if (result.empty() || result.find("Caption") != std::string::npos) {
        return "Not Found";
    }
    return result;
}

std::string SystemInfoCollector::GetStorageCapacity() {
    ULARGE_INTEGER freeBytesAvailable, totalNumberOfBytes, totalNumberOfFreeBytes;
    
    if (GetDiskFreeSpaceExA("C:\\", &freeBytesAvailable, &totalNumberOfBytes, &totalNumberOfFreeBytes)) {
        std::ostringstream oss;
        oss << (totalNumberOfBytes.QuadPart / (1024 * 1024 * 1024)) << " GB";
        return oss.str();
    }
    return "Unknown";
}

std::string SystemInfoCollector::GetPCName() {
    char computerName[MAX_COMPUTERNAME_LENGTH + 1];
    DWORD size = sizeof(computerName);
    if (GetComputerNameA(computerName, &size)) {
        return std::string(computerName);
    }
    return "Unknown";
}

std::string SystemInfoCollector::GetIPAddress() {
    char hostname[256];
    if (gethostname(hostname, sizeof(hostname)) == SOCKET_ERROR) {
        return "Unknown";
    }

    struct addrinfo hints, *info;
    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    if (getaddrinfo(hostname, NULL, &hints, &info) != 0) {
        return "Unknown";
    }

    struct sockaddr_in* addr = (struct sockaddr_in*)info->ai_addr;
    std::string ip = inet_ntoa(addr->sin_addr);
    freeaddrinfo(info);
    return ip;
}

std::string SystemInfoCollector::executeCommand(const std::string& command) {
    std::string result;
    FILE* pipe = _popen(command.c_str(), "r");
    if (!pipe) return "";

    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
        result += buffer;
    }
    _pclose(pipe);

    // Clean up the result
    size_t pos = result.find('\n');
    if (pos != std::string::npos) {
        result = result.substr(0, pos);
    }
    
    // Remove any trailing whitespace
    while (!result.empty() && std::isspace(result.back())) {
        result.pop_back();
    }

    return result;
}

std::string SystemInfoCollector::sha256Hash(const std::string& input) {
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    BYTE rgbHash[32];
    DWORD cbHash = 32;
    CHAR rgbDigits[] = "0123456789abcdef";

    if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
        return "";
    }

    if (!CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
        CryptReleaseContext(hProv, 0);
        return "";
    }

    if (!CryptHashData(hHash, (BYTE*)input.c_str(), static_cast<DWORD>(input.length()), 0)) {
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return "";
    }

    if (!CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return "";
    }

    std::string hash;
    for (DWORD i = 0; i < cbHash; i++) {
        hash += rgbDigits[rgbHash[i] >> 4];
        hash += rgbDigits[rgbHash[i] & 0xf];
    }

    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);
    return hash;
}

} // namespace RegzAuth

#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include "RegzAuth.h"
#include "internal/AuthManager.h"
#include "internal/SystemInfo.h"
#include "internal/HttpClient.h"
#include <iostream>

namespace RegzAuth {

RegzAuth::RegzAuth() {
    authManager = std::make_unique<AuthManager>();
}

RegzAuth::~RegzAuth() {
}

bool RegzAuth::Initialize(const AuthConfig& config) {
    this->config = config;
    
    authManager->SetSupabaseConfig(config.supabaseUrl, config.supabaseKey);
    authManager->SetAppVersion(config.appVersion);
    
    return true;
}

bool RegzAuth::RegisterUser(const std::string& username, const std::string& password, const std::string& licenseKey) {
    if (!authManager) return false;
    
    bool result = authManager->RegisterUser(username, password, licenseKey);
    
    if (result && config.onRegisterSuccess) {
        config.onRegisterSuccess("Registration successful!");
    } else if (!result && config.onRegisterFailed) {
        config.onRegisterFailed("Registration failed. Please check your information and license key.");
    }
    
    return result;
}

bool RegzAuth::LoginUser(const std::string& username, const std::string& password) {
    if (!authManager) return false;
    
    bool result = authManager->CheckLogin(username, password);
    
    if (result && config.onLoginSuccess) {
        config.onLoginSuccess("Login successful!");
    } else if (!result && config.onLoginFailed) {
        config.onLoginFailed("Login failed. Please check your credentials.");
    }
    
    return result;
}

std::string RegzAuth::GetHWID() {
    if (!authManager) return "";
    
    SystemInfoCollector systemInfo;
    return systemInfo.GetHWID();
}

std::string RegzAuth::GetSystemInfo() {
    if (!authManager) return "";
    
    SystemInfoCollector systemInfo;
    SystemInfo info = systemInfo.GetSystemInfo();
    
    std::string result = "PC Name: " + info.pcName + "\n";
    result += "IP Address: " + info.ipAddress + "\n";
    result += "HWID: " + info.hwid + "\n";
    result += "OS Version: " + info.osVersion + "\n";
    result += "RAM: " + info.ramCapacity + "\n";
    result += "Graphics: " + info.graphicsCard + "\n";
    result += "Storage: " + info.storageCapacity + "\n";
    
    return result;
}

bool RegzAuth::CheckVersion() {
    if (!authManager) return false;
    return authManager->CheckVersion();
}

void RegzAuth::SetConfig(const AuthConfig& config) {
    this->config = config;
    if (authManager) {
        authManager->SetSupabaseConfig(config.supabaseUrl, config.supabaseKey);
        authManager->SetAppVersion(config.appVersion);
    }
}

AuthConfig RegzAuth::GetConfig() const {
    return config;
}

} // namespace RegzAuth

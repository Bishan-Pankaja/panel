#pragma once

// RegzAuth - Modular Authentication System
// Easy to integrate into any C++ project

#ifndef REGZAUTH_H
#define REGZAUTH_H

#include <string>
#include <memory>
#include <functional>

namespace RegzAuth {

    // Forward declarations
    class AuthManager;
    class SystemInfoCollector;
    class HttpClient;

    // Configuration structure for easy setup
    struct AuthConfig {
        std::string supabaseUrl;
        std::string supabaseKey;
        std::string appVersion = "1.1";
        std::string appName = "Regz Auth";
        
        // Optional callbacks for custom behavior
        std::function<void(const std::string&)> onMessage;
        std::function<void(const std::string&)> onLoginSuccess;
        std::function<void(const std::string&)> onLoginFailed;
        std::function<void(const std::string&)> onRegisterSuccess;
        std::function<void(const std::string&)> onRegisterFailed;
    };

    // Main authentication class - simple interface
    class RegzAuth {
    public:
        RegzAuth();
        ~RegzAuth();

        // Initialize with configuration
        bool Initialize(const AuthConfig& config);

        // Authentication methods
        bool RegisterUser(const std::string& username, const std::string& password, const std::string& licenseKey);
        bool LoginUser(const std::string& username, const std::string& password);
        
        // Utility methods
        std::string GetHWID();
        std::string GetSystemInfo();
        bool CheckVersion();
        
        // Configuration
        void SetConfig(const AuthConfig& config);
        AuthConfig GetConfig() const;

    private:
        std::unique_ptr<AuthManager> authManager;
        AuthConfig config;
    };

} // namespace RegzAuth

#endif // REGZAUTH_H

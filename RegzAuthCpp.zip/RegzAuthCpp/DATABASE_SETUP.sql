-- ===========================================
-- Regz Auth C++ - Database Setup
-- ===========================================
-- Run this in your Supabase SQL Editor
-- ===========================================

-- STEP 1: Create test license keys
INSERT INTO public.license_keys (
    license_key, 
    admin_approval,     -- CRITICAL: Must be TRUE for registration to work!
    banned, 
    max_devices, 
    duration_days,
    subscription
) VALUES (
    'TEST-KEY-2024-DEMO',
    true,               -- ✅ Enable this!
    false,
    3,                  -- Allow 3 devices
    365,                -- Valid for 365 days
    '["default"]'::jsonb
);

-- Add more test keys
INSERT INTO public.license_keys (
    license_key, 
    admin_approval, 
    banned, 
    max_devices, 
    duration_days,
    subscription
) VALUES 
    ('PREMIUM-2024-TEST', true, false, 5, 365, '["default"]'::jsonb),
    ('VIP-2024-GOLD', true, false, 10, 730, '["default"]'::jsonb);


-- STEP 2: Enable ALL existing license keys (if you have any)
UPDATE public.license_keys 
SET admin_approval = true, 
    banned = false,
    duration_days = 365
WHERE admin_approval = false OR admin_approval IS NULL;


-- STEP 3: Check your license keys
SELECT 
    license_key, 
    admin_approval, 
    banned, 
    max_devices, 
    duration_days,
    subscription
FROM public.license_keys
ORDER BY id DESC;


-- ===========================================
-- HOW TO USE:
-- ===========================================
-- 1. Run this SQL in Supabase SQL Editor
-- 2. Use "TEST-KEY-2024-DEMO" to register
-- 3. Enter username, password, and the key
-- 4. Click "Register"
-- 5. Login with your username/password
-- ===========================================

-- ===========================================
-- TROUBLESHOOTING:
-- ===========================================
-- If registration fails, check:
--   ✅ admin_approval = true
--   ✅ banned = false
--   ✅ duration_days > 0
--   ✅ license_key exists
--
-- If login fails, check users table:
SELECT username, admin_approval, banned, expiredate 
FROM public.users 
WHERE username = 'YOUR_USERNAME';
-- ===========================================


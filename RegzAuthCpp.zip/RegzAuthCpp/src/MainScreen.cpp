#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN

#include "MainScreen.h"
#include <windowsx.h>
#include <commctrl.h>

#pragma comment(lib, "comctl32.lib")

// Control IDs
#define IDC_WELCOME          2001
#define IDC_USERNAME         2002
#define IDC_SUBSCRIPTION     2003
#define IDC_BTN_LOGOUT       2004
#define IDC_BTN_BACK         2005

// Colors matching the dark theme
#define COLOR_BACKGROUND    RGB(21, 21, 21)      // #151515
#define COLOR_BUTTON_BG     RGB(33, 33, 33)      // #212121
#define COLOR_LOGIN_BTN     RGB(0, 191, 255)     // #00BFFF
#define COLOR_TEXT_WHITE    RGB(255, 255, 255)   // #FFFFFF
#define COLOR_TEXT_BLACK    RGB(0, 0, 0)         // #000000

MainScreen::MainScreen()
    : hDialog(nullptr)
    , hWelcomeLabel(nullptr)
    , hUsernameLabel(nullptr)
    , hSubscriptionLabel(nullptr)
    , hLogoutBtn(nullptr)
    , hBackBtn(nullptr)
    , hTitleFont(nullptr)
    , hNormalFont(nullptr)
    , hBackgroundBrush(nullptr)
{
    hBackgroundBrush = CreateSolidBrush(COLOR_BACKGROUND);
}

MainScreen::~MainScreen() {
    if (hTitleFont) DeleteObject(hTitleFont);
    if (hNormalFont) DeleteObject(hNormalFont);
    if (hBackgroundBrush) DeleteObject(hBackgroundBrush);
}

void MainScreen::CreateControls(HWND hwnd, const std::string& username, const std::string& subscriptions) {
    // Create fonts - same as login screen
    hTitleFont = CreateFontA(28, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial");

    hNormalFont = CreateFontA(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial");

    // Title - centered like login screen
    hWelcomeLabel = CreateWindowA("STATIC", "Welcome to Main Screen!",
        WS_CHILD | WS_VISIBLE | SS_CENTER,
        0, 30, 510, 40, hwnd, (HMENU)IDC_WELCOME, nullptr, nullptr);
    SendMessage(hWelcomeLabel, WM_SETFONT, (WPARAM)hTitleFont, TRUE);

    // Username info - centered
    std::string usernameText = "Logged in as: " + username;
    hUsernameLabel = CreateWindowA("STATIC", usernameText.c_str(),
        WS_CHILD | WS_VISIBLE | SS_CENTER,
        0, 90, 510, 30, hwnd, (HMENU)IDC_USERNAME, nullptr, nullptr);
    SendMessage(hUsernameLabel, WM_SETFONT, (WPARAM)hNormalFont, TRUE);

    // Subscription info - centered
    std::string subText = "Subscription: " + subscriptions;
    hSubscriptionLabel = CreateWindowA("STATIC", subText.c_str(),
        WS_CHILD | WS_VISIBLE | SS_CENTER,
        0, 130, 510, 30, hwnd, (HMENU)IDC_SUBSCRIPTION, nullptr, nullptr);
    SendMessage(hSubscriptionLabel, WM_SETFONT, (WPARAM)hNormalFont, TRUE);

    // Logout button - centered like login buttons
    hLogoutBtn = CreateWindowA("BUTTON", "Logout",
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        105, 180, 300, 28, hwnd, (HMENU)IDC_BTN_LOGOUT, nullptr, nullptr);
    SendMessage(hLogoutBtn, WM_SETFONT, (WPARAM)hNormalFont, TRUE);

    // Back to Login button - like register button
    hBackBtn = CreateWindowA("BUTTON", "Back to Login",
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        105, 213, 300, 28, hwnd, (HMENU)IDC_BTN_BACK, nullptr, nullptr);
    SendMessage(hBackBtn, WM_SETFONT, (WPARAM)hNormalFont, TRUE);
}

LRESULT MainScreen::HandleCtlColorStatic(HWND hwnd, HDC hdc) {
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, COLOR_TEXT_WHITE);
    return (LRESULT)hBackgroundBrush;
}

INT_PTR CALLBACK MainScreen::DialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    MainScreen* pThis = nullptr;

    if (msg == WM_INITDIALOG) {
        SetWindowLongPtr(hwnd, GWLP_USERDATA, lParam);
        pThis = reinterpret_cast<MainScreen*>(lParam);
        pThis->hDialog = hwnd;
    } else {
        pThis = reinterpret_cast<MainScreen*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
    }

    if (!pThis) return FALSE;

    switch (msg) {
    case WM_INITDIALOG: {
        // Get username and subscriptions from lParam
        std::string* data = reinterpret_cast<std::string*>(lParam);
        std::string username = data[0];
        std::string subscriptions = data[1];
        pThis->CreateControls(hwnd, username, subscriptions);
        return TRUE;
    }

    case WM_ERASEBKGND: {
        RECT rect;
        GetClientRect(hwnd, &rect);
        FillRect((HDC)wParam, &rect, pThis->hBackgroundBrush);
        return TRUE;
    }

    case WM_CTLCOLORSTATIC:
        return pThis->HandleCtlColorStatic((HWND)lParam, (HDC)wParam);

    case WM_DRAWITEM: {
        LPDRAWITEMSTRUCT pDIS = (LPDRAWITEMSTRUCT)lParam;
        if (pDIS->CtlID == IDC_BTN_LOGOUT || pDIS->CtlID == IDC_BTN_BACK) {
            // Custom button drawing
            HBRUSH hBrush;
            COLORREF textColor;

            if (pDIS->CtlID == IDC_BTN_LOGOUT) {
                hBrush = CreateSolidBrush(COLOR_LOGIN_BTN);
                textColor = COLOR_TEXT_BLACK;
            } else {
                hBrush = CreateSolidBrush(COLOR_BUTTON_BG);
                textColor = COLOR_TEXT_WHITE;
            }

            FillRect(pDIS->hDC, &pDIS->rcItem, hBrush);
            DeleteObject(hBrush);

            // Draw text
            char text[256];
            GetWindowTextA(pDIS->hwndItem, text, 256);
            SetBkMode(pDIS->hDC, TRANSPARENT);
            SetTextColor(pDIS->hDC, textColor);

            HFONT hFont = (HFONT)SendMessage(pDIS->hwndItem, WM_GETFONT, 0, 0);
            HFONT hOldFont = (HFONT)SelectObject(pDIS->hDC, hFont);

            DrawTextA(pDIS->hDC, text, -1, &pDIS->rcItem,
                DT_CENTER | DT_VCENTER | DT_SINGLELINE);

            SelectObject(pDIS->hDC, hOldFont);
            return TRUE;
        }
        break;
    }

    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case IDC_BTN_LOGOUT:
            pThis->OnLogoutClick();
            return TRUE;
        case IDC_BTN_BACK:
            pThis->OnBackClick();
            return TRUE;
        }
        break;

    case WM_CLOSE:
        EndDialog(hwnd, 0);
        return TRUE;
    }

    return FALSE;
}

void MainScreen::OnLogoutClick() {
    if (hDialog) {
        EndDialog(hDialog, 0);
    }
}

void MainScreen::OnBackClick() {
    if (hDialog) {
        EndDialog(hDialog, 1); // Return 1 to indicate "back to login"
    }
}

int MainScreen::Show(HINSTANCE hInstance, const std::string& username, const std::string& subscriptions) {
    // Create data array to pass username and subscriptions
    std::string data[2] = {username, subscriptions};
    
    return (int)DialogBoxParamA(hInstance, MAKEINTRESOURCEA(2), nullptr,
        DialogProc, (LPARAM)data);
}

void MainScreen::Close() {
    if (hDialog) {
        EndDialog(hDialog, 0);
    }
}


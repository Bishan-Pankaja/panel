#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN

#include "LoginGUI.h"
#include "MainScreen.h"
#include <windowsx.h>
#include <shlobj.h>
#include <fstream>
#include <sstream>
#include <commctrl.h>
#include <shellapi.h>  // Add this for ShellExecuteA

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")  // Add this for ShellExecuteA

// Control IDs
#define IDC_TITLE           1001
#define IDC_USERNAME        1002
#define IDC_PASSWORD        1003
#define IDC_LICENSEKEY      1004
#define IDC_BTN_LOGIN       1005
#define IDC_BTN_REGISTER    1006
#define IDC_LINK_BUY        1007

// Colors matching the Python design
#define COLOR_BACKGROUND    RGB(21, 21, 21)      // #151515
#define COLOR_CONTROL_BG    RGB(44, 44, 44)      // #2c2c2c
#define COLOR_BUTTON_BG     RGB(33, 33, 33)      // #212121
#define COLOR_LOGIN_BTN     RGB(0, 191, 255)     // #00BFFF
#define COLOR_TEXT_WHITE    RGB(255, 255, 255)   // #FFFFFF
#define COLOR_TEXT_BLACK    RGB(0, 0, 0)         // #000000

LoginGUI::LoginGUI()
    : hDialog(nullptr)
    , hUsername(nullptr)
    , hPassword(nullptr)
    , hLicenseKey(nullptr)
    , hLoginBtn(nullptr)
    , hRegisterBtn(nullptr)
    , hBuyAccountLink(nullptr)
    , hTitleFont(nullptr)
    , hNormalFont(nullptr)
    , hLinkFont(nullptr)
    , hBackgroundBrush(nullptr)
    , hControlBrush(nullptr)
{
    hBackgroundBrush = CreateSolidBrush(COLOR_BACKGROUND);
    hControlBrush = CreateSolidBrush(COLOR_CONTROL_BG);
}

LoginGUI::~LoginGUI() {
    if (hTitleFont) DeleteObject(hTitleFont);
    if (hNormalFont) DeleteObject(hNormalFont);
    if (hLinkFont) DeleteObject(hLinkFont);
    if (hBackgroundBrush) DeleteObject(hBackgroundBrush);
    if (hControlBrush) DeleteObject(hControlBrush);
}

std::string LoginGUI::GetControlText(HWND hwnd) {
    int len = GetWindowTextLengthW(hwnd);
    if (len == 0) return "";

    std::wstring wstr(len + 1, 0);
    GetWindowTextW(hwnd, &wstr[0], len + 1);

    int size = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, nullptr, 0, nullptr, nullptr);
    std::string str(size, 0);
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &str[0], size, nullptr, nullptr);

    return str.c_str();
}

void LoginGUI::SetControlText(HWND hwnd, const std::string& text) {
    int size = MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, nullptr, 0);
    std::wstring wstr(size, 0);
    MultiByteToWideChar(CP_UTF8, 0, text.c_str(), -1, &wstr[0], size);
    SetWindowTextW(hwnd, wstr.c_str());
}

void LoginGUI::CreateCustomControls(HWND hwnd) {
    // Create fonts
    hTitleFont = CreateFontA(28, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial");

    hNormalFont = CreateFontA(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial");

    hLinkFont = CreateFontA(14, 0, 0, 0, FW_NORMAL, FALSE, TRUE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial");

    // Title
    HWND hTitle = CreateWindowA("STATIC", "Regz Auth Py Example",
        WS_CHILD | WS_VISIBLE | SS_CENTER,
        0, 30, 510, 40, hwnd, (HMENU)IDC_TITLE, nullptr, nullptr);
    SendMessage(hTitle, WM_SETFONT, (WPARAM)hTitleFont, TRUE);

    // Username entry
    hUsername = CreateWindowExA(0, "EDIT", "",
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
        95, 90, 320, 29, hwnd, (HMENU)IDC_USERNAME, nullptr, nullptr);
    SendMessage(hUsername, WM_SETFONT, (WPARAM)hNormalFont, TRUE);
    SendMessageA(hUsername, EM_SETCUEBANNER, FALSE, (LPARAM)"Username");

    // Password entry
    hPassword = CreateWindowExA(0, "EDIT", "",
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_PASSWORD | ES_AUTOHSCROLL,
        95, 129, 320, 29, hwnd, (HMENU)IDC_PASSWORD, nullptr, nullptr);
    SendMessage(hPassword, WM_SETFONT, (WPARAM)hNormalFont, TRUE);
    SendMessageA(hPassword, EM_SETCUEBANNER, FALSE, (LPARAM)"Password");

    // License key entry
    hLicenseKey = CreateWindowExA(0, "EDIT", "",
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
        95, 168, 320, 29, hwnd, (HMENU)IDC_LICENSEKEY, nullptr, nullptr);
    SendMessage(hLicenseKey, WM_SETFONT, (WPARAM)hNormalFont, TRUE);
    SendMessageA(hLicenseKey, EM_SETCUEBANNER, FALSE, (LPARAM)"License Key");

    // Login button
    hLoginBtn = CreateWindowA("BUTTON", "Login",
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        105, 207, 300, 28, hwnd, (HMENU)IDC_BTN_LOGIN, nullptr, nullptr);
    SendMessage(hLoginBtn, WM_SETFONT, (WPARAM)hNormalFont, TRUE);

    // Register button
    hRegisterBtn = CreateWindowA("BUTTON", "Register",
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        105, 240, 300, 28, hwnd, (HMENU)IDC_BTN_REGISTER, nullptr, nullptr);
    SendMessage(hRegisterBtn, WM_SETFONT, (WPARAM)hNormalFont, TRUE);

    // Buy Account link
    hBuyAccountLink = CreateWindowA("STATIC", "Buy Account",
        WS_CHILD | WS_VISIBLE | SS_CENTER | SS_NOTIFY,
        180, 278, 150, 20, hwnd, (HMENU)IDC_LINK_BUY, nullptr, nullptr);
    SendMessage(hBuyAccountLink, WM_SETFONT, (WPARAM)hLinkFont, TRUE);
}

LRESULT LoginGUI::HandleCtlColorStatic(HWND hwnd, HDC hdc) {
    SetBkMode(hdc, TRANSPARENT);

    int ctrlId = GetDlgCtrlID(hwnd);
    if (ctrlId == IDC_LINK_BUY) {
        SetTextColor(hdc, COLOR_LOGIN_BTN);
    }
    else {
        SetTextColor(hdc, COLOR_TEXT_WHITE);
    }

    return (LRESULT)hBackgroundBrush;
}

LRESULT LoginGUI::HandleCtlColorEdit(HWND hwnd, HDC hdc) {
    SetTextColor(hdc, COLOR_TEXT_WHITE);
    SetBkColor(hdc, COLOR_CONTROL_BG);
    return (LRESULT)hControlBrush;
}

INT_PTR CALLBACK LoginGUI::DialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    LoginGUI* pThis = nullptr;

    if (msg == WM_INITDIALOG) {
        SetWindowLongPtr(hwnd, GWLP_USERDATA, lParam);
        pThis = reinterpret_cast<LoginGUI*>(lParam);
        pThis->hDialog = hwnd;
    }
    else {
        pThis = reinterpret_cast<LoginGUI*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
    }

    if (!pThis) return FALSE;

    switch (msg) {
    case WM_INITDIALOG:
        pThis->CreateCustomControls(hwnd);
        pThis->LoadCredentials();
        return TRUE;

    case WM_ERASEBKGND: {
        RECT rect;
        GetClientRect(hwnd, &rect);
        FillRect((HDC)wParam, &rect, pThis->hBackgroundBrush);
        return TRUE;
    }

    case WM_CTLCOLORSTATIC:
        return pThis->HandleCtlColorStatic((HWND)lParam, (HDC)wParam);

    case WM_CTLCOLOREDIT:
        return pThis->HandleCtlColorEdit((HWND)lParam, (HDC)wParam);

    case WM_DRAWITEM: {
        LPDRAWITEMSTRUCT pDIS = (LPDRAWITEMSTRUCT)lParam;
        if (pDIS->CtlID == IDC_BTN_LOGIN || pDIS->CtlID == IDC_BTN_REGISTER) {
            // Custom button drawing
            HBRUSH hBrush;
            COLORREF textColor;

            if (pDIS->CtlID == IDC_BTN_LOGIN) {
                hBrush = CreateSolidBrush(COLOR_LOGIN_BTN);
                textColor = COLOR_TEXT_BLACK;
            }
            else {
                hBrush = CreateSolidBrush(COLOR_BUTTON_BG);
                textColor = COLOR_TEXT_WHITE;
            }

            FillRect(pDIS->hDC, &pDIS->rcItem, hBrush);
            DeleteObject(hBrush);

            // Draw text
            char text[256];
            GetWindowTextA(pDIS->hwndItem, text, 256);
            SetBkMode(pDIS->hDC, TRANSPARENT);
            SetTextColor(pDIS->hDC, textColor);

            HFONT hFont = (HFONT)SendMessage(pDIS->hwndItem, WM_GETFONT, 0, 0);
            HFONT hOldFont = (HFONT)SelectObject(pDIS->hDC, hFont);

            DrawTextA(pDIS->hDC, text, -1, &pDIS->rcItem,
                DT_CENTER | DT_VCENTER | DT_SINGLELINE);

            SelectObject(pDIS->hDC, hOldFont);
            return TRUE;
        }
        break;
    }

    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case IDC_BTN_LOGIN:
            pThis->OnLoginClick();
            return TRUE;
        case IDC_BTN_REGISTER:
            pThis->OnRegisterClick();
            return TRUE;
        case IDC_LINK_BUY:
            if (HIWORD(wParam) == STN_CLICKED) {
                pThis->OnBuyAccountClick();
            }
            return TRUE;
        }
        break;

    case WM_CLOSE:
        if (pThis->onClose) {
            pThis->onClose();
        }
        EndDialog(hwnd, 0);
        return TRUE;
    }

    return FALSE;
}

void LoginGUI::OnLoginClick() {
    std::string username = GetControlText(hUsername);
    std::string password = GetControlText(hPassword);

    if (username.empty() || password.empty()) {
        ShowMessage("Please enter username and password.");
        return;
    }

    if (onLogin) {
        onLogin(username, password);
    }
}

void LoginGUI::OnRegisterClick() {
    std::string username = GetControlText(hUsername);
    std::string password = GetControlText(hPassword);
    std::string licenseKey = GetControlText(hLicenseKey);

    if (username.empty() || password.empty() || licenseKey.empty()) {
        ShowMessage("Please fill in all fields.");
        return;
    }

    if (onRegister) {
        onRegister(username, password, licenseKey);
    }
}

void LoginGUI::OnBuyAccountClick() {
    if (onBuyAccount) {
        onBuyAccount("https://regzcheat.org/");
    }
    else {
        ShellExecuteA(nullptr, "open", "https://regzcheat.org/", nullptr, nullptr, SW_SHOW);
    }
}

void LoginGUI::LoadCredentials() {
    char appData[MAX_PATH];
    if (SHGetFolderPathA(nullptr, CSIDL_APPDATA, nullptr, 0, appData) != S_OK) {
        return;
    }

    std::string credPath = std::string(appData) + "\\RegzAuthCppExample.json";
    std::ifstream file(credPath);
    if (!file.is_open()) return;

    std::stringstream buffer;
    buffer << file.rdbuf();
    std::string content = buffer.str();
    file.close();

    // Simple JSON parsing (username and password only)
    size_t usernamePos = content.find("\"username\":\"");
    if (usernamePos != std::string::npos) {
        size_t start = usernamePos + 12;
        size_t end = content.find("\"", start);
        std::string username = content.substr(start, end - start);
        SetControlText(hUsername, username);
    }

    size_t passwordPos = content.find("\"password\":\"");
    if (passwordPos != std::string::npos) {
        size_t start = passwordPos + 12;
        size_t end = content.find("\"", start);
        std::string password = content.substr(start, end - start);
        SetControlText(hPassword, password);
    }
}

void LoginGUI::SaveCredentials(const std::string& username, const std::string& password) {
    char appData[MAX_PATH];
    if (SHGetFolderPathA(nullptr, CSIDL_APPDATA, nullptr, 0, appData) != S_OK) {
        return;
    }

    std::string credPath = std::string(appData) + "\\RegzAuthCppExample.json";
    std::ofstream file(credPath);
    if (!file.is_open()) return;

    file << "{\"username\":\"" << username << "\",\"password\":\"" << password << "\"}";
    file.close();
}

int LoginGUI::Show(HINSTANCE hInstance) {
    return (int)DialogBoxParamA(hInstance, MAKEINTRESOURCEA(1), nullptr,
        DialogProc, (LPARAM)this);
}

void LoginGUI::Close() {
    if (hDialog) {
        EndDialog(hDialog, 0);
    }
}

void LoginGUI::ShowMessage(const std::string& message) {
    MessageBoxA(hDialog, message.c_str(), "Message", MB_OK | MB_ICONINFORMATION);
}

void LoginGUI::NavigateToMainScreen(const std::string& subscriptions) {
    // Close login dialog
    if (hDialog) {
        EndDialog(hDialog, 1);
    }
    
    // Show main screen
    MainScreen mainScreen;
    std::string username = GetControlText(hUsername);
    int result = mainScreen.Show(GetModuleHandle(nullptr), username, subscriptions);
    
    // If user clicked "Back to Login", show login dialog again
    if (result == 1) {
        Show(GetModuleHandle(nullptr));
    }
}
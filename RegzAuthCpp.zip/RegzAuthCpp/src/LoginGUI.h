#pragma once

#include <windows.h>
#include <string>
#include <functional>

class LoginGUI {
public:
    LoginGUI();
    ~LoginGUI();

    int Show(HINSTANCE hInstance);
    void Close();
    void ShowMessage(const std::string& message);
    void NavigateToMainScreen(const std::string& subscriptions);

    // Credential management
    void LoadCredentials();
    void SaveCredentials(const std::string& username, const std::string& password);

    // Control text management
    std::string GetControlText(HWND hwnd);
    void SetControlText(HWND hwnd, const std::string& text);

    // Callbacks
    std::function<void(const std::string&, const std::string&)> onLogin;
    std::function<void(const std::string&, const std::string&, const std::string&)> onRegister;
    std::function<void(const std::string&)> onBuyAccount;
    std::function<void()> onClose;

private:
    HWND hDialog;
    HWND hUsername;
    HWND hPassword;
    HWND hLicenseKey;
    HWND hLoginBtn;
    HWND hRegisterBtn;
    HWND hBuyAccountLink;

    HFONT hTitleFont;
    HFONT hNormalFont;
    HFONT hLinkFont;

    HBRUSH hBackgroundBrush;
    HBRUSH hControlBrush;

    void CreateCustomControls(HWND hwnd);
    void OnLoginClick();
    void OnRegisterClick();
    void OnBuyAccountClick();

    LRESULT HandleCtlColorStatic(HWND hwnd, HDC hdc);
    LRESULT HandleCtlColorEdit(HWND hwnd, HDC hdc);

    static INT_PTR CALLBACK DialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
};
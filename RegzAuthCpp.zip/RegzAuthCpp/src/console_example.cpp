#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <windows.h>
#include <iostream>
#include "../regzauth/RegzAuth.h"

// Simple console-based example
int main() {
    std::cout << "=== RegzAuth Console Example ===" << std::endl;
    
    // Create and configure RegzAuth
    RegzAuth::RegzAuth auth;
    
    RegzAuth::AuthConfig config;
    config.supabaseUrl = "https://tevmesjpsrsiuwswgzfb.supabase.co";
    config.supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRldm1lc2pwc3JzaXV3c3dnemZiIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0ODM4NTEwOCwiZXhwIjoyMDYzOTYxMTA4fQ.pqvIZEiFyRC4308-Z2crZ2Oueki2CRzsUb5t_RUcEX8";
    config.appVersion = "10.3";
    config.appName = "Console Example";
    
    // Initialize
    if (!auth.Initialize(config)) {
        std::cerr << "Failed to initialize RegzAuth" << std::endl;
        return 1;
    }
    
    std::cout << "RegzAuth initialized successfully!" << std::endl;
    
    // Get system information
    std::cout << "\n=== System Information ===" << std::endl;
    std::string hwid = auth.GetHWID();
    std::cout << "HWID: " << hwid << std::endl;
    
    std::string sysInfo = auth.GetSystemInfo();
    std::cout << "System Info:\n" << sysInfo << std::endl;
    
    // Check version
    std::cout << "\n=== Version Check ===" << std::endl;
    bool versionOk = auth.CheckVersion();
    std::cout << "Version Check: " << (versionOk ? "OK" : "Failed") << std::endl;
    
    // Example login (you would get these from user input in a real app)
    std::cout << "\n=== Authentication Test ===" << std::endl;
    std::string username, password;
    
    std::cout << "Enter username: ";
    std::getline(std::cin, username);
    
    std::cout << "Enter password: ";
    std::getline(std::cin, password);
    
    if (auth.LoginUser(username, password)) {
        std::cout << "Login successful!" << std::endl;
    } else {
        std::cout << "Login failed!" << std::endl;
    }
    
    std::cout << "\nPress Enter to exit...";
    std::cin.get();
    
    return 0;
}

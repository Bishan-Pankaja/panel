#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <windows.h>
#include <iostream>
#include <shellapi.h>
#include "LoginGUI.h"
#include "../regzauth/RegzAuth.h"

#pragma comment(lib, "shell32.lib")

// Global auth instance
RegzAuth::RegzAuth* g_auth = nullptr;
LoginGUI* g_gui = nullptr;

void HandleLoginSuccess(const std::string& username, const std::string& password) {
    // Save credentials
    g_gui->SaveCredentials(username, password);
    
    // Navigate to main screen (in a real app, this would open your main application window)
    g_gui->NavigateToMainScreen("default");
}

void HandleLoginFailed(const std::string& error) {
    g_gui->ShowMessage("Login failed: " + error);
}

void HandleRegisterSuccess(const std::string& username, const std::string& password) {
    // Save credentials
    g_gui->SaveCredentials(username, password);
    
    g_gui->ShowMessage("Registration successful! You can now log in.");
}

void HandleRegisterFailed(const std::string& error) {
    g_gui->ShowMessage("Registration failed: " + error);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // Initialize COM
    CoInitialize(nullptr);
    
    try {
        // Initialize RegzAuth backend
        g_auth = new RegzAuth::RegzAuth();
        
        RegzAuth::AuthConfig config;
        config.supabaseUrl = "";
        config.supabaseKey = "";
        config.appVersion = "1.0";
        config.appName = "Regz Auth Py Example";
        
        if (!g_auth->Initialize(config)) {
            MessageBoxA(nullptr, "Failed to initialize RegzAuth backend", "Error", MB_OK | MB_ICONERROR);
            delete g_auth;
            CoUninitialize();
            return 1;
        }
        
        // Create GUI
        g_gui = new LoginGUI();
        
        // Set up GUI callbacks
        g_gui->onLogin = [](const std::string& username, const std::string& password) {
            // Perform login
            if (g_auth->LoginUser(username, password)) {
                HandleLoginSuccess(username, password);
            } else {
                HandleLoginFailed("Invalid credentials or account not approved");
            }
        };
        
        g_gui->onRegister = [](const std::string& username, const std::string& password, const std::string& licenseKey) {
            // Perform registration
            if (g_auth->RegisterUser(username, password, licenseKey)) {
                HandleRegisterSuccess(username, password);
            } else {
                HandleRegisterFailed("Invalid license key or registration failed");
            }
        };
        
        g_gui->onBuyAccount = [](const std::string& url) {
            ShellExecuteA(nullptr, "open", url.c_str(), nullptr, nullptr, SW_SHOW);
        };
        
        g_gui->onClose = []() {
            // Cleanup when user closes the dialog
        };
        
        // Show the GUI
        int result = g_gui->Show(hInstance);
        
        // Cleanup
        delete g_gui;
        delete g_auth;
        
    } catch (const std::exception& e) {
        std::string error = "Exception: " + std::string(e.what());
        MessageBoxA(nullptr, error.c_str(), "Error", MB_OK | MB_ICONERROR);
        if (g_gui) delete g_gui;
        if (g_auth) delete g_auth;
        CoUninitialize();
        return 1;
    } catch (...) {
        MessageBoxA(nullptr, "Unknown error occurred", "Error", MB_OK | MB_ICONERROR);
        if (g_gui) delete g_gui;
        if (g_auth) delete g_auth;
        CoUninitialize();
        return 1;
    }
    
    // Cleanup
    CoUninitialize();
    return 0;
}

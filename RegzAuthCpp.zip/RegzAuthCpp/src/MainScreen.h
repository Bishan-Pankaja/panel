#pragma once

#include <windows.h>
#include <string>

// Main screen after successful login
class MainScreen {
public:
    MainScreen();
    ~MainScreen();

    // Show the main screen
    int Show(HINSTANCE hInstance, const std::string& username, const std::string& subscriptions);
    void Close();

private:
    HWND hDialog;
    HWND hWelcomeLabel;
    HWND hUsernameLabel;
    HWND hSubscriptionLabel;
    HWND hLogoutBtn;
    HWND hBackBtn;

    HFONT hTitleFont;
    HFONT hNormalFont;
    HBRUSH hBackgroundBrush;

    static INT_PTR CALLBACK DialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    void CreateControls(HWND hwnd, const std::string& username, const std::string& subscriptions);
    LRESULT HandleCtlColorStatic(HWND hwnd, HDC hdc);
    void OnLogoutClick();
    void OnBackClick();
};


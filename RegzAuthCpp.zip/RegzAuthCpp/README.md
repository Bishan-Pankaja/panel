# RegzAuth C++ - Modern Dark Theme GUI

A beautiful, modern C++ authentication system with a dark-themed GUI, inspired by Python's customtkinter design.

## 🎨 Features

- ✅ **Dark Theme UI** - Modern black theme matching the Python design (#151515 background)
- ✅ **No CMD Window** - Pure GUI application (no console window appears)
- ✅ **Credential Saving** - Automatically saves and loads username/password
- ✅ **Clean Separation** - GUI code in `src/`, backend in `regzauth/`
- ✅ **Supabase Integration** - Full authentication with license key validation
- ✅ **HWID Protection** - Hardware ID tracking and device limits
- ✅ **Admin Approval System** - License keys require approval before use
- ✅ **Version Checking** - Automatic app version validation

## 📁 Project Structure

```
RegzAuthCpp/
├── regzauth/              ← Backend authentication system (no GUI)
│   ├── RegzAuth.h/cpp           - Main auth API
│   └── internal/
│       ├── AuthManager.h/cpp     - Core authentication logic
│       ├── HttpClient.h/cpp      - Supabase HTTP client
│       ├── SystemInfo.h/cpp      - HWID and system info
│       └── RegzAuthInternal.h    - Shared structs
│
└── src/                   ← GUI and example code
    ├── LoginGUI.h/cpp            - Dark theme login GUI
    ├── LoginGUI.rc               - GUI resources
    └── gui_example.cpp           - Example integration
```

## 🚀 Quick Start

### 1. Open in Visual Studio
```bash
cd RegzAuthCpp
start RegzAuthCpp.sln
```

### 2. Build and Run
- Press `F5` or click "Start Debugging"
- No CMD window will appear - just the GUI!

### 3. Configure Your Supabase

Edit `src/gui_example.cpp`:

```cpp
config.supabaseUrl = "YOUR_SUPABASE_URL";
config.supabaseKey = "YOUR_SUPABASE_KEY";
config.appVersion = "1.0";
```

## 📊 Database Setup

Run this SQL in your Supabase dashboard to create test data:

```sql
-- Create a test license key
INSERT INTO public.license_keys (
    license_key, 
    admin_approval,     -- MUST BE TRUE!
    banned, 
    max_devices, 
    duration_days,
    subscription
) VALUES (
    'TEST-KEY-2024-DEMO',
    true,               -- Enable admin approval
    false,
    3,
    365,
    '["default"]'::jsonb
);

-- Or enable all existing keys
UPDATE public.license_keys 
SET admin_approval = true, 
    banned = false,
    duration_days = 365
WHERE admin_approval = false;
```

## 🎮 Usage

### Register a New User
1. Enter username, password, and license key
2. Click "Register"
3. License key must have `admin_approval = true` in database

### Login
1. Enter your username and password
2. Click "Login"
3. Credentials are automatically saved

### Buy Account Link
- Click the "Buy Account" link to open your sales page
- Customizable in `src/gui_example.cpp`

## 🎨 GUI Design

The GUI matches the Python customtkinter design:

- **Background**: `#151515` (RGB 21, 21, 21)
- **Controls**: `#2c2c2c` (RGB 44, 44, 44)
- **Login Button**: `#00BFFF` (Cyan)
- **Register Button**: `#212121` (Dark gray)
- **Link Color**: `#00BFFF` (Cyan)
- **Text Color**: `#FFFFFF` (White)

## 🔧 Integration into Your Project

### Option 1: Copy the `regzauth` folder

```cpp
#include "regzauth/RegzAuth.h"

RegzAuth::RegzAuth auth;
RegzAuth::AuthConfig config;
config.supabaseUrl = "YOUR_URL";
config.supabaseKey = "YOUR_KEY";
config.appVersion = "1.0";

auth.SetConfig(config);
if (auth.Initialize()) {
    // Ready to use!
}
```

### Option 2: Use the complete GUI

Copy both `regzauth/` and `src/LoginGUI.h/cpp` to your project.

## 📝 Key Notes

### Why Registration Fails

Registration will fail if:
- ❌ License key doesn't exist in `license_keys` table
- ❌ `admin_approval = false` (MUST BE TRUE!)
- ❌ `banned = true`
- ❌ License key already used
- ❌ `duration_days` is NULL or 0

### Why Login Fails

Login will fail if:
- ❌ Username/password incorrect
- ❌ User is banned (`banned = true`)
- ❌ Subscription expired (`expiredate` passed)
- ❌ No admin approval (`admin_approval = false`)
- ❌ HWID mismatch (device limit exceeded)

### Credential Storage

Credentials are saved to:
```
%APPDATA%\RegzAuthCppExample.json
```

Format:
```json
{"username":"testuser","password":"test123"}
```

## 🛠️ Customization

### Change Colors

Edit `src/LoginGUI.cpp`:

```cpp
#define COLOR_BACKGROUND    RGB(21, 21, 21)      // #151515
#define COLOR_CONTROL_BG    RGB(44, 44, 44)      // #2c2c2c
#define COLOR_BUTTON_BG     RGB(33, 33, 33)      // #212121
#define COLOR_LOGIN_BTN     RGB(0, 191, 255)     // #00BFFF
```

### Change Window Size

Edit `src/LoginGUI.rc`:

```rc
1 DIALOGEX 0, 0, 510, 320  // width, height
```

### Add Main Screen

After successful login, customize in `src/LoginGUI.cpp`:

```cpp
void LoginGUI::NavigateToMainScreen(const std::string& subscriptions) {
    // Add your main application window here
    MessageBoxA(nullptr, 
                ("Welcome!\nSubscriptions: " + subscriptions).c_str(), 
                "Main Screen", 
                MB_OK);
}
```

## 🔒 Security Features

- ✅ HWID tracking (SHA-256 of motherboard serial)
- ✅ Device limits (max_devices)
- ✅ IP address logging
- ✅ System information collection
- ✅ Subscription expiration
- ✅ Admin approval system
- ✅ Ban system

## 📦 Dependencies

All dependencies are Windows built-in:
- `wininet.lib` - HTTP requests
- `crypt32.lib` - SHA-256 hashing
- `advapi32.lib` - System info
- `psapi.lib` - Process info
- `iphlpapi.lib` - Network info
- `ws2_32.lib` - Winsock
- `comctl32.lib` - Common controls

## 🐛 Troubleshooting

### "Failed to initialize RegzAuth backend"
- Check your Supabase URL and API key
- Ensure you have internet connection

### "Registration failed"
- Run the SQL to enable `admin_approval = true`
- Check that the license key exists in your database
- Verify `duration_days` is set (e.g., 365)

### "Login failed"
- Verify username and password are correct
- Check that `admin_approval = true` for the user
- Ensure user is not banned
- Check that subscription hasn't expired

### GUI doesn't show
- Ensure `SubSystem` is set to `Windows` (not `Console`)
- Check that `LoginGUI.rc` is included in the project

## 📄 License

This is a demo/template project. Customize and use as needed!

## 🙏 Credits

Based on Regz Auth system with a modern C++ implementation.
GUI design inspired by Python's customtkinter library.

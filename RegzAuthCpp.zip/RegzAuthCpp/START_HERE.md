# 🚀 START HERE - RegzAuth C++

## ✨ What You Have

A **professional dark-themed login/registration GUI** for C++ that looks exactly like Python's customtkinter design!

```
┌────────────────────────────────────────┐
│    Regz Auth Py Example                │
│                                        │
│    [Username         ]                 │ ← Dark theme
│    [Password         ]                 │   #151515
│    [License Key      ]                 │   background
│                                        │
│    [      Login      ]  ← Cyan         │
│    [    Register     ]  ← Dark gray    │
│                                        │
│       Buy Account       ← Cyan link    │
└────────────────────────────────────────┘
No CMD window · Credential saving · Full auth
```

---

## 🎯 3 Steps to Get Running

### Step 1: Setup Database (2 minutes)
1. Open Supabase Dashboard → SQL Editor
2. Copy ALL of `DATABASE_SETUP.sql`
3. Click "Run"

**Done!** Test keys created with `admin_approval = true`

---

### Step 2: Configure (1 minute)
Edit `src/gui_example.cpp` lines 45-46:

```cpp
config.supabaseUrl = "YOUR_SUPABASE_URL";  // ← Change this
config.supabaseKey = "YOUR_SERVICE_ROLE_KEY";  // ← Change this
```

**Where to find:**
- Supabase Dashboard → Settings → API
- Copy `URL` and `service_role` key

---

### Step 3: Build & Run (1 minute)
```bash
cd RegzAuthCpp
start RegzAuthCpp.sln
# Press F5 in Visual Studio
```

**Done!** GUI appears (no CMD window!)

---

## 🎮 Test It

### Register
1. **Username**: `testuser`
2. **Password**: `test123`  
3. **License Key**: `TEST-KEY-2024-DEMO`
4. Click "Register"

### Login
1. **Username**: `testuser`
2. **Password**: `test123`
3. Click "Login"

**Success!** 🎉

---

## 📚 Documentation

| Need | Read |
|------|------|
| **Quick start** | [QUICK_START.md](QUICK_START.md) |
| **Full docs** | [README.md](README.md) |
| **Visual design** | [VISUAL_GUIDE.md](VISUAL_GUIDE.md) |
| **Testing** | [TEST_STEPS.md](TEST_STEPS.md) |
| **All docs** | [INDEX.md](INDEX.md) |

---

## 🐛 Common Issues

### "Registration failed"
→ Run `DATABASE_SETUP.sql` in Supabase

### "Login failed"  
→ Make sure you registered first with a valid license key

### "Failed to initialize"
→ Check Supabase URL and Key in `gui_example.cpp`

### CMD window appears
→ Project should be `RegzAuthCpp` (GUI), not `RegzAuthConsole`

---

## 📁 Project Structure

```
RegzAuthCpp/
├── regzauth/              ← Backend (no GUI)
│   ├── RegzAuth.h/cpp           - Main API
│   └── internal/                - Auth, HTTP, System info
│
├── src/                   ← GUI (dark theme)
│   ├── LoginGUI.h/cpp           - GUI implementation
│   ├── LoginGUI.rc              - GUI resources
│   └── gui_example.cpp          - Example usage
│
├── DATABASE_SETUP.sql     ← Run this first!
├── QUICK_START.md         ← 5-minute guide
└── README.md              ← Complete docs
```

---

## ✅ What You Get

- ✅ **Dark theme** matching Python customtkinter (#151515)
- ✅ **No CMD window** - pure GUI application
- ✅ **Credential saving** - auto-fills username/password
- ✅ **Full authentication** - Supabase integration
- ✅ **HWID protection** - device limits
- ✅ **Admin approval** - license key system
- ✅ **Clean code** - backend in `regzauth/`, GUI in `src/`
- ✅ **Easy integration** - copy `regzauth/` to your project

---

## 🎨 Customization

### Change Colors
Edit `src/LoginGUI.cpp`:
```cpp
#define COLOR_BACKGROUND RGB(21, 21, 21)    // #151515
#define COLOR_LOGIN_BTN  RGB(0, 191, 255)   // #00BFFF
```

### Change Window Size
Edit `src/LoginGUI.rc`:
```rc
1 DIALOGEX 0, 0, 510, 320  // width, height
```

### Change "Buy Account" URL
Edit `src/gui_example.cpp`:
```cpp
ShellExecuteA(nullptr, "open", "YOUR_URL_HERE", ...);
```

---

## 🎉 That's It!

You're ready to use your professional C++ authentication system!

**Questions?** Check [INDEX.md](INDEX.md) for all documentation.

**Happy coding!** 🚀


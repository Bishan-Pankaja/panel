# 🚀 Quick Start Guide - RegzAuth C++

Get up and running in 5 minutes!

## ⚡ Step 1: Database Setup

1. Open your Supabase SQL Editor
2. Copy and paste the entire `DATABASE_SETUP.sql` file
3. Click "Run" to create test license keys

## 🔧 Step 2: Configure Supabase

Edit `src/gui_example.cpp` (lines 44-48):

```cpp
config.supabaseUrl = "YOUR_SUPABASE_URL";  // ← Change this
config.supabaseKey = "YOUR_SUPABASE_KEY";  // ← Change this
config.appVersion = "1.0";
```

**Where to find these:**
- Login to Supabase Dashboard
- Go to Project Settings → API
- Copy `URL` and `service_role key` (NOT anon key!)

## 🏃 Step 3: Build & Run

### Option A: Visual Studio
```bash
1. Open RegzAuthCpp.sln
2. Press F5
3. Done! No CMD window will appear
```

### Option B: Command Line
```bash
cd RegzAuthCpp
build.bat
```

## 🎮 Step 4: Test Registration

In the GUI that appears:

1. **Username**: `testuser`
2. **Password**: `test123`
3. **License Key**: `TEST-KEY-2024-DEMO`
4. Click **"Register"**

✅ You should see: "Registration successful!"

## 🔐 Step 5: Test Login

1. **Username**: `testuser`
2. **Password**: `test123`
3. Click **"Login"**

✅ You should see: Welcome screen!

## 🎨 What You'll See

The GUI looks like this:
- **Dark theme** (#151515 background)
- **Modern controls** (#2c2c2c input fields)
- **Cyan login button** (#00BFFF)
- **No console window** - pure GUI!

## 🐛 Common Issues

### "Registration failed"
**Solution:** Run `DATABASE_SETUP.sql` in Supabase to enable license keys

### "Login failed"  
**Solution:** Make sure you registered first!

### "Failed to initialize"
**Solution:** Check your Supabase URL and API key in `gui_example.cpp`

### CMD window appears
**Solution:** Make sure you're building the GUI project (RegzAuthCpp), not the Console project

## 📝 Next Steps

1. **Customize Colors**: Edit `src/LoginGUI.cpp` color defines
2. **Add Main Screen**: Modify `LoginGUI::NavigateToMainScreen()`
3. **Change Window Size**: Edit `src/LoginGUI.rc`
4. **Integrate**: Copy `regzauth/` folder to your project

## 💡 Tips

- Credentials are auto-saved to `%APPDATA%\RegzAuthCppExample.json`
- Click "Buy Account" link to open https://regzcheat.org/
- Use `console_example.cpp` for debugging without GUI

## 🎯 Test License Keys

Created by `DATABASE_SETUP.sql`:
- `TEST-KEY-2024-DEMO` (3 devices, 365 days)
- `PREMIUM-2024-TEST` (5 devices, 365 days)
- `VIP-2024-GOLD` (10 devices, 730 days)

## 📚 Full Documentation

See `README.md` for complete documentation, integration guide, and customization options.

---

**🎉 That's it! You're ready to use RegzAuth C++!**

